package beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MovieBean:
 * - Connects to MySQL database CSD430 using JDBC
 * - Provides methods for:
 *   1) Getting all movie_id values (dropdown)
 *   2) Getting one record by movie_id (details page)
 *   3) Adding a new movie record (insert)
 *   4) Getting all movies (display all records)
 *
 *
 */
public class MovieBean {

    // Database configuration 
	private final String jdbcUrl =
		    "jdbc:mysql://localhost:3306/CSD430?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private final String jdbcUser = "student1";
    private final String jdbcPass = "pass";

    /**
     * Opens and returns a new DB connection.
     */
    private Connection getConnection() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); } catch (ClassNotFoundException ignored) {}
        return DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPass);
    }

    /**
     * Returns all movie_id values for the dropdown list.
     */
    public List<Integer> getAllMovieIds() throws SQLException {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT movie_id FROM james_movies_data ORDER BY movie_id";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ids.add(rs.getInt("movie_id"));
            }
        }
        return ids;
    }

    /**
     * 
     */
    public ResultSet getMovieById(int movieId) throws SQLException {
        Connection conn = getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT movie_id, title, genre, director, release_year, rating " +
            "FROM james_movies_data WHERE movie_id = ?"
        );
        ps.setInt(1, movieId);
        return ps.executeQuery();
    }

    /**
     * Inserts a new movie record into the database.
     * movie_id is AUTO_INCREMENT so it is generated automatically.
     *
     * @return number of rows inserted (1 if successful)
     */
    public int addMovie(String title, String genre, String director, int releaseYear, double rating) throws SQLException {
        String sql = "INSERT INTO james_movies_data (title, genre, director, release_year, rating) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, title);
            ps.setString(2, genre);
            ps.setString(3, director);
            ps.setInt(4, releaseYear);
            ps.setDouble(5, rating);

            return ps.executeUpdate();
        }
    }

    /**
     * Returns ALL movie records for display.
     */
    public ResultSet getAllMovies() throws SQLException {
        Connection conn = getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT movie_id, title, genre, director, release_year, rating " +
            "FROM james_movies_data ORDER BY movie_id"
        );
        return ps.executeQuery();
    }
}
