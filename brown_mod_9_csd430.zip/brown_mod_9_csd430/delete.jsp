<%@ page import="beans.MovieBean, java.sql.ResultSet, java.util.List" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CSD430 Movie Project - Delete Records</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .container { max-width: 950px; margin: 0 auto; }
    .card { border: 1px solid #ccc; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
    label { font-weight: bold; }
    select { padding: 8px; width: 100%; max-width: 420px; }
    button { padding: 10px 14px; cursor: pointer; }
    table { border-collapse: collapse; width: 100%; margin-top: 12px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    thead th { background: #f3f3f3; }
    .msg { padding: 10px; border-radius: 6px; margin-top: 10px; }
    .success { background: #e9f7ef; border: 1px solid #b7e1c1; }
    .error { background: #fdecea; border: 1px solid #f5c2c7; }
    .nav a { margin-right: 12px; }
  </style>
</head>
<body>
<div class="container">

<h1>Delete Movie Records</h1>
<p>
  This page displays all records from the database table and allows the user to delete a selected record
  using the primary key (movie_id). After deletion, the page reloads showing remaining records and keys.
</p>

<div class="card nav">
  <strong>Navigation:</strong>
  <a href="index.jsp">Add & View All</a>
  <a href="update_select.jsp">Update a Record</a>
  <a href="delete.jsp">Delete a Record</a>
</div>

<%
  // Handles deletion and retrieves updated data
  MovieBean bean = new MovieBean();
  String message = null;
  String error = null;

  // If submitted, delete the selected record
  if ("POST".equalsIgnoreCase(request.getMethod())) {
      try {
          String idParam = request.getParameter("movieId");
          if (idParam != null && idParam.trim().length() > 0) {
              int movieId = Integer.parseInt(idParam);
              int rows = bean.deleteMovie(movieId);

              if (rows == 1) {
                  message = "Success! Record with movie_id " + movieId + " was deleted.";
              } else {
                  message = "No record was deleted. The key may not exist.";
              }
          } else {
              error = "No key was selected.";
          }
      } catch (Exception e) {
          error = e.getMessage();
      }
  }

  // Fetch remaining keys and records
  List<Integer> ids = null;
  ResultSet rs = null;

  try {
      ids = bean.getAllMovieIds();
      rs = bean.getAllMovies();
  } catch (Exception e) {
      error = (error == null) ? e.getMessage() : error;
  }
%>

<% if (message != null) { %>
  <div class="msg success"><strong><%= message %></strong></div>
<% } %>

<% if (error != null) { %>
  <div class="msg error"><strong>Error:</strong> <%= error %></div>
<% } %>

<div class="card">
  <h2>Select a Record to Delete</h2>
  <p>The dropdown shows the remaining primary keys (movie_id). Select one and submit to delete.</p>

  <form method="post" action="delete.jsp">
    <label for="movieId">Movie ID:</label><br>
    <select id="movieId" name="movieId" <%= (ids == null || ids.size() == 0) ? "disabled" : "" %>>
      <% if (ids != null && ids.size() > 0) { %>
        <% for (Integer id : ids) { %>
          <option value="<%= id %>"><%= id %></option>
        <% } %>
      <% } else { %>
        <option value="">(No records available)</option>
      <% } %>
    </select>
    <br><br>
    <button type="submit" <%= (ids == null || ids.size() == 0) ? "disabled" : "" %>>Delete Selected Record</button>
  </form>
</div>

<div class="card">
  <h2>All Remaining Records</h2>
  <p>The table below shows all remaining records after deletions. If no records remain, the header still displays.</p>

  <table>
    <thead>
      <tr>
        <th>movie_id</th>
        <th>title</th>
        <th>genre</th>
        <th>director</th>
        <th>release_year</th>
        <th>rating</th>
      </tr>
    </thead>
    <tbody>
      <%
        boolean anyRows = false;
        if (rs != null) {
            while (rs.next()) {
                anyRows = true;
      %>
        <tr>
          <td><%= rs.getInt("movie_id") %></td>
          <td><%= rs.getString("title") %></td>
          <td><%= rs.getString("genre") %></td>
          <td><%= rs.getString("director") %></td>
          <td><%= rs.getInt("release_year") %></td>
          <td><%= rs.getDouble("rating") %></td>
        </tr>
      <%
            }
        }
        if (!anyRows) {
      %>
        <tr>
          <td colspan="6">(No records remain)</td>
        </tr>
      <%
        }
      %>
    </tbody>
  </table>
</div>

</div>
</body>
</html>