<%@ page import="beans.MovieBean, java.sql.ResultSet" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CSD430 Movie Project - Add & View Movies</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .container { max-width: 950px; margin: 0 auto; }
    .card { border: 1px solid #ccc; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
    .nav a { margin-right: 12px; }
    label { font-weight: bold; }
    input, select { padding: 8px; width: 100%; max-width: 420px; }
    button { padding: 10px 14px; cursor: pointer; }
    table { border-collapse: collapse; width: 100%; margin-top: 12px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    thead th { background: #f3f3f3; }
    .msg { padding: 10px; border-radius: 6px; margin-top: 10px; }
    .success { background: #e9f7ef; border: 1px solid #b7e1c1; }
    .error { background: #fdecea; border: 1px solid #f5c2c7; }
    hr { margin: 18px 0; }
  </style>
</head>
<body>
<div class="container">

  <h1>CSD430 Movie Project</h1>
  <p>
    This page allows a user to add a new movie record to the database.
    After submission, the page displays all records currently stored in the table.
  </p>

  <div class="card nav">
    <strong>Navigation:</strong>
    <a href="index.jsp">Add & View All</a>
    <a href="update_select.jsp">Update a Record</a>
    <a href="details.jsp?movieId=1">View One Record (example)</a>
    <a href="delete.jsp">Delete a Record</a>
  </div>

  <div class="card">
    <h2>Add a New Movie Record</h2>
    <p>
      Enter movie details below. The primary key (movie_id) is created automatically when you submit.
    </p>

    <form method="post" action="index.jsp">
      <label for="title">Title:</label><br>
      <input type="text" id="title" name="title" maxlength="150" required><br><br>

      <label for="genre">Genre:</label><br>
      <input type="text" id="genre" name="genre" maxlength="50" required><br><br>

      <label for="director">Director:</label><br>
      <input type="text" id="director" name="director" maxlength="100" required><br><br>

      <label for="releaseYear">Release Year:</label><br>
      <input type="number" id="releaseYear" name="releaseYear" min="1888" max="2100" required><br><br>

      <label for="rating">Rating (0.0 - 9.9):</label><br>
      <input type="number" id="rating" name="rating" step="0.1" min="0.0" max="9.9" required><br><br>

      <button type="submit">Add Movie</button>
    </form>
  </div>

  <%
    // Handles insert and retrieval of all records
    MovieBean bean = new MovieBean();

    String message = null;
    String error = null;

    if ("POST".equalsIgnoreCase(request.getMethod())) {
        try {
            String title = request.getParameter("title");
            String genre = request.getParameter("genre");
            String director = request.getParameter("director");
            int releaseYear = Integer.parseInt(request.getParameter("releaseYear"));
            double rating = Double.parseDouble(request.getParameter("rating"));

            int rows = bean.addMovie(title, genre, director, releaseYear, rating);

            if (rows == 1) {
                message = "Success! New movie record was added to the database.";
            } else {
                error = "Insert did not complete as expected (no rows inserted).";
            }
        } catch (Exception e) {
            error = e.getMessage();
        }
    }

    ResultSet rs = null;
    try {
        rs = bean.getAllMovies();
    } catch (Exception e) {
        error = (error == null) ? e.getMessage() : error;
    }
  %>

  <% if (message != null) { %>
    <div class="msg success"><strong><%= message %></strong></div>
  <% } %>

  <% if (error != null) { %>
    <div class="msg error"><strong>Error:</strong> <%= error %></div>
  <% } %>

  <div class="card">
    <h2>All Movie Records</h2>
    <p>Below is a complete listing of all records stored in <strong>james_movies_data</strong>.</p>

    <table>
      <thead>
        <tr>
          <th>movie_id</th>
          <th>title</th>
          <th>genre</th>
          <th>director</th>
          <th>release_year</th>
          <th>rating</th>
        </tr>
      </thead>
      <tbody>
        <%
          if (rs != null) {
              while (rs.next()) {
        %>
          <tr>
            <td><%= rs.getInt("movie_id") %></td>
            <td><%= rs.getString("title") %></td>
            <td><%= rs.getString("genre") %></td>
            <td><%= rs.getString("director") %></td>
            <td><%= rs.getInt("release_year") %></td>
            <td><%= rs.getDouble("rating") %></td>
          </tr>
        <%
              }
          }
        %>
      </tbody>
    </table>
  </div>

</div>
</body>
</html>
