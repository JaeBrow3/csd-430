package beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MovieBean {

    private final String jdbcUrl =
        "jdbc:mysql://localhost:3306/CSD430?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private final String jdbcUser = "student1";
    private final String jdbcPass = "pass";

    private Connection getConnection() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); } catch (ClassNotFoundException ignored) {}
        return DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPass);
    }

    // Returns key values for dropdown menus
    public List<Integer> getAllMovieIds() throws SQLException {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT movie_id FROM james_movies_data ORDER BY movie_id";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) ids.add(rs.getInt("movie_id"));
        }
        return ids;
    }

    // Returns a single record by key
    public ResultSet getMovieById(int movieId) throws SQLException {
        Connection conn = getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT movie_id, title, genre, director, release_year, rating " +
            "FROM james_movies_data WHERE movie_id = ?"
        );
        ps.setInt(1, movieId);
        return ps.executeQuery();
    }

    // Updates a record by key
    public int updateMovie(int movieId, String title, String genre, String director, int releaseYear, double rating)
            throws SQLException {
        String sql =
            "UPDATE james_movies_data " +
            "SET title = ?, genre = ?, director = ?, release_year = ?, rating = ? " +
            "WHERE movie_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, title);
            ps.setString(2, genre);
            ps.setString(3, director);
            ps.setInt(4, releaseYear);
            ps.setDouble(5, rating);
            ps.setInt(6, movieId);

            return ps.executeUpdate(); // 1 if updated
        }
    }

    // Returns all records (optional, kept for continuity)
    public ResultSet getAllMovies() throws SQLException {
        Connection conn = getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT movie_id, title, genre, director, release_year, rating " +
            "FROM james_movies_data ORDER BY movie_id"
        );
        return ps.executeQuery();
    }

    // Inserts a new record (optional, kept for continuity)
    public int addMovie(String title, String genre, String director, int releaseYear, double rating) throws SQLException {
        String sql = "INSERT INTO james_movies_data (title, genre, director, release_year, rating) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, genre);
            ps.setString(3, director);
            ps.setInt(4, releaseYear);
            ps.setDouble(5, rating);
            return ps.executeUpdate();
        }
    }
    
     // Deletes a record by key
        public int deleteMovie(int movieId) throws SQLException {
            String sql = "DELETE FROM james_movies_data WHERE movie_id = ?";

            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, movieId);
                return ps.executeUpdate(); // 1 if deleted
            }
        }
    }