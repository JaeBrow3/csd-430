package beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MovieBean: Provides DB access methods for JSP pages using JDBC.
 */
public class MovieBean {

    private final String jdbcUrl = "jdbc:mysql://localhost:3306/CSD430?useSSL=false&serverTimezone=UTC";
    private final String jdbcUser = "student1";
    private final String jdbcPass = "pass";

    private Connection getConnection() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); } catch (ClassNotFoundException ignored) {}
        return DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPass);
    }

    /** Returns all movie_id values for the dropdown list. */
    public List<Integer> getAllMovieIds() throws SQLException {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT movie_id FROM james_movies_data ORDER BY movie_id";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ids.add(rs.getInt("movie_id"));
            }
        }
        return ids;
    }

    /** Returns one movie row by its primary key. */
    public ResultSet getMovieById(int movieId) throws SQLException {
        Connection conn = getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT movie_id, title, genre, director, release_year, rating " +
            "FROM james_movies_data WHERE movie_id = ?"
        );
        ps.setInt(1, movieId);
        return ps.executeQuery(); // JSP will read it
    }
}
