<%@ page import="beans.MovieBean, java.sql.ResultSet" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Update Movie - Result</title>
</head>
<body>

<h1>Update Result</h1>
<p>The record below reflects the updated values stored in the database.</p>

<%
  String error = null;
  String message = null;

  int movieId = -1;
  String title = null;
  String genre = null;
  String director = null;
  int releaseYear = 0;
  double rating = 0.0;

  ResultSet rs = null;

  try {
    movieId = Integer.parseInt(request.getParameter("movieId"));
    title = request.getParameter("title");
    genre = request.getParameter("genre");
    director = request.getParameter("director");
    releaseYear = Integer.parseInt(request.getParameter("releaseYear"));
    rating = Double.parseDouble(request.getParameter("rating"));

    MovieBean bean = new MovieBean();
    int rows = bean.updateMovie(movieId, title, genre, director, releaseYear, rating);

    if (rows == 1) {
      message = "Success! Record was updated.";
    } else {
      message = "No rows updated. Verify the selected key exists.";
    }

    rs = bean.getMovieById(movieId);

  } catch (Exception e) {
    error = e.getMessage();
  }
%>

<% if (error != null) { %>
  <p><strong>Error:</strong> <%= error %></p>
<% } else { %>

<% if (message != null) { %>
  <p><strong><%= message %></strong></p>
<% } %>

<% if (rs != null && rs.next()) { %>

<h2>Updated Record</h2>

<table border="1">
  <thead>
    <tr>
      <th>movie_id (INT)</th>
      <th>title (VARCHAR)</th>
      <th>genre (VARCHAR)</th>
      <th>director (VARCHAR)</th>
      <th>release_year (YEAR)</th>
      <th>rating (DECIMAL)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><%= rs.getInt("movie_id") %></td>
      <td><%= rs.getString("title") %></td>
      <td><%= rs.getString("genre") %></td>
      <td><%= rs.getString("director") %></td>
      <td><%= rs.getInt("release_year") %></td>
      <td><%= rs.getDouble("rating") %></td>
    </tr>
  </tbody>
</table>

<% } else { %>
  <p><strong>No record found after update.</strong></p>
<% } %>

<p><a href="update_select.jsp">Update Another Record</a></p>
<p><a href="index.jsp">Back to Main Page</a></p>

<% } %>

</body>
</html>
