<%@ page import="beans.MovieBean, java.sql.ResultSet" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CSD430 Movie Project - Details</title>
</head>
<body>

<h1>Movie Record Details</h1>
<p>The selected movie record is shown below.</p>

<%
  String error = null;
  ResultSet rs = null;

  try {
    int movieId = Integer.parseInt(request.getParameter("movieId"));
    MovieBean bean = new MovieBean();
    rs = bean.getMovieById(movieId);
  } catch (Exception e) {
    error = e.getMessage();
  }
%>

<% if (error != null) { %>
  <p><strong>Error:</strong> <%= error %></p>
<% } else if (rs != null && rs.next()) { %>

  <table border="1">
    <thead>
      <tr>
        <th>movie_id</th>
        <th>title</th>
        <th>genre</th>
        <th>director</th>
        <th>release_year</th>
        <th>rating</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><%= rs.getInt("movie_id") %></td>
        <td><%= rs.getString("title") %></td>
        <td><%= rs.getString("genre") %></td>
        <td><%= rs.getString("director") %></td>
        <td><%= rs.getInt("release_year") %></td>
        <td><%= rs.getDouble("rating") %></td>
      </tr>
    </tbody>
  </table>

<% } else { %>
  <p><strong>No record found.</strong></p>
<% } %>

<p><a href="index.jsp">Back to Main Page</a></p>

</body>
</html>

