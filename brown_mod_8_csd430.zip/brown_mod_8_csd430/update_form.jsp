<%@ page import="beans.MovieBean, java.sql.ResultSet" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Update Movie - Edit Form</title>
</head>
<body>

<h1>Edit Movie Record</h1>
<p>The primary key is shown but cannot be changed. Update the fields and submit.</p>

<%
  String error = null;
  ResultSet rs = null;
  int movieId = -1;

  try {
    movieId = Integer.parseInt(request.getParameter("movieId"));
    MovieBean bean = new MovieBean();
    rs = bean.getMovieById(movieId);
  } catch (Exception e) {
    error = e.getMessage();
  }
%>

<% if (error != null) { %>
  <p><strong>Error:</strong> <%= error %></p>
<% } else if (rs != null && rs.next()) { %>

<form method="post" action="update_result.jsp">
  <p><strong>movie_id (not editable):</strong> <%= rs.getInt("movie_id") %></p>
  <input type="hidden" name="movieId" value="<%= rs.getInt("movie_id") %>">

  <label for="title">Title:</label><br>
  <input type="text" id="title" name="title" value="<%= rs.getString("title") %>" maxlength="150" required><br><br>

  <label for="genre">Genre:</label><br>
  <input type="text" id="genre" name="genre" value="<%= rs.getString("genre") %>" maxlength="50" required><br><br>

  <label for="director">Director:</label><br>
  <input type="text" id="director" name="director" value="<%= rs.getString("director") %>" maxlength="100" required><br><br>

  <label for="releaseYear">Release Year:</label><br>
  <input type="number" id="releaseYear" name="releaseYear" value="<%= rs.getInt("release_year") %>" min="1888" max="2100" required><br><br>

  <label for="rating">Rating (0.0 - 9.9):</label><br>
  <input type="number" id="rating" name="rating" value="<%= rs.getDouble("rating") %>" step="0.1" min="0.0" max="9.9" required><br><br>

  <button type="submit">Update Record</button>
</form>

<% } else { %>
  <p><strong>No record found.</strong></p>
<% } %>

<p><a href="update_select.jsp">Back to Select</a></p>

</body>
</html>
