<%@ page import="beans.MovieBean, java.util.List" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Update Movie - Select Record</title>
</head>
<body>

<h1>Update Movie Record</h1>
<p>Select a movie_id to update. The dropdown contains only primary key values.</p>

<%
  MovieBean bean = new MovieBean();
  List<Integer> ids = null;
  String error = null;

  try {
    ids = bean.getAllMovieIds();
  } catch (Exception e) {
    error = e.getMessage();
  }
%>

<% if (error != null) { %>
  <p><strong>Error:</strong> <%= error %></p>
<% } else { %>

<form method="post" action="update_form.jsp">
  <label for="movieId">Movie ID:</label>
  <select id="movieId" name="movieId">
    <% for (Integer id : ids) { %>
      <option value="<%= id %>"><%= id %></option>
    <% } %>
  </select>
  <button type="submit">Load Record</button>
</form>

<% } %>

</body>
</html>
