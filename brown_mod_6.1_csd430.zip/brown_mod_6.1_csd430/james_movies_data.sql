-- ============================================
-- CSD430 Project Part 1
-- Topic: Movies
-- Database: CSD430
-- Table: james_movies_data
-- ============================================

CREATE DATABASE IF NOT EXISTS CSD430;
USE CSD430;

DROP TABLE IF EXISTS james_movies_data;

CREATE TABLE james_movies_data (
  movie_id INT NOT NULL AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  genre VARCHAR(50) NOT NULL,
  director VARCHAR(100) NOT NULL,
  release_year YEAR NOT NULL,
  rating DECIMAL(2,1) NOT NULL,
  PRIMARY KEY (movie_id)
);

INSERT INTO james_movies_data (title, genre, director, release_year, rating) VALUES
('The Shawshank Redemption', 'Drama', 'Frank Darabont', 1994, 9.3),
('The Godfather', 'Crime', 'Francis Ford Coppola', 1972, 9.2),
('The Dark Knight', 'Action', 'Christopher Nolan', 2008, 9.0),
('Pulp Fiction', 'Crime', 'Quentin Tarantino', 1994, 8.9),
('Forrest Gump', 'Drama', 'Robert Zemeckis', 1994, 8.8),
('Inception', 'Sci-Fi', 'Christopher Nolan', 2010, 8.8),
('Fight Club', 'Drama', 'David Fincher', 1999, 8.8),
('The Matrix', 'Sci-Fi', 'Lana Wachowski', 1999, 8.7),
('Interstellar', 'Sci-Fi', 'Christopher Nolan', 2014, 8.7),
('Gladiator', 'Action', 'Ridley Scott', 2000, 8.5);

SHOW DATABASES;
SHOW TABLES;
DESCRIBE james_movies_data;
SELECT * FROM james_movies_data;
